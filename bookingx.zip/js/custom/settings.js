
jQuery(document).ready(function(){
tinyMCE.init({
        mode : "textareas"
});
});

jQuery(document).ready(function(){


	jQuery('#id_text_color').iris({
		width: 300,
		hide: true,
		palettes: true
	});
	
	
	jQuery('#id_background_color').iris({
		width: 300,
		hide: true,
		palettes: true
	});

	
	jQuery('#id_border_color').iris({
		width: 300,
		hide: true,
		palettes: true
	});


	jQuery('#id_progressbar_color').iris({
		width: 300,
		hide: true,
		palettes: true
	});
	
});

